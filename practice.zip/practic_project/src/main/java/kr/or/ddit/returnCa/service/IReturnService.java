package kr.or.ddit.returnCa.service;

import java.util.List;

import kr.or.ddit.returnCa.vo.ReturnVo;

public interface IReturnService {
	
	public List<ReturnVo> returnList();

}
