package kr.or.ddit.returnCa.dao;

import java.util.List;

import kr.or.ddit.returnCa.vo.ReturnVo;

public interface IReturnDao {
	
	public List<ReturnVo> returnList();

}
