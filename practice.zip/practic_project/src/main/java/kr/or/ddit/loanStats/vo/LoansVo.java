package kr.or.ddit.loanStats.vo;

public class LoansVo {
	private String monthNo;
	private int count;
	
	
	public String getMonthNo() {
		return monthNo;
	}
	public void setMonthNo(String monthNo) {
		this.monthNo = monthNo;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	
}
