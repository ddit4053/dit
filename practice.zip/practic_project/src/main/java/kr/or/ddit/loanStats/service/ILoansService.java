package kr.or.ddit.loanStats.service;

import java.util.List;

import kr.or.ddit.loanStats.vo.LoansVo;

public interface ILoansService {
	
	public List<LoansVo> loansList();

}
